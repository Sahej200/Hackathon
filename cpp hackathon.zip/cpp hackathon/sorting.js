// Function to sort news items based on selected order
function sortNews() {
    var newsContainer = document.getElementById('news-container');
    var newsItems = newsContainer.querySelectorAll('.news-item');
    var sortingOrder = document.getElementById('sortingOrder').value;
  
    var sortedNewsItems = Array.from(newsItems);
  
    sortedNewsItems.sort(function(a, b) {
      var dateA = new Date(a.dataset.date);
      var dateB = new Date(b.dataset.date);
      
      if (sortingOrder === 'asc') {
        return dateA - dateB;
      } else {
        return dateB - dateA;
      }
    });
  
    // Remove existing news items from container
    while (newsContainer.firstChild) {
      newsContainer.removeChild(newsContainer.firstChild);
    }
  
    // Append sorted news items to container
    sortedNewsItems.forEach(function(item) {
      newsContainer.appendChild(item);
    });
  }
  
  // Call sortNews function initially to sort news items
  sortNews();
  